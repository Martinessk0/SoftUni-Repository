﻿namespace FoodShortage
{
    public interface IIdentifable
    {
        string Id { get; set; }
    }
}
