﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public static class ExceptionMessages
    {
        public static string InvalidPhoneNumbersException
            => "Invalid number!";
        public static string InvalidUrlsException
            => "Invalid URL!";
    }
}
