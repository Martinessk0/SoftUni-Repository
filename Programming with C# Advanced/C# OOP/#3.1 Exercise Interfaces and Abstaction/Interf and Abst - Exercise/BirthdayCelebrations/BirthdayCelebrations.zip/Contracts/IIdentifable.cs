﻿namespace BirthdayCelebrations
{
    public interface IIdentifable
    {
        string Id { get; set; }
    }
}
