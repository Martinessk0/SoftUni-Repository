﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
    //"name": "3M Company",
    //"isImporter": true
    public class SupplierDto
    {
        public string Name { get; set; }
        public bool IsImporter { get; set; }
    }
}
